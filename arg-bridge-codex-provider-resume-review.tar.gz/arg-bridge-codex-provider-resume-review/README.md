# Codex Provider 切换后 Resume 失败修复：审查交接

## 1. 交接摘要

本包只提交一个**待审查的远程分支**，不创建 PR、不修改目标分支、不发布 Release。

| 项目 | 内容 |
| --- | --- |
| 仓库 | `Arginine-Arg/Feishu_bridge_arg` |
| 审查分支 | `review/codex-provider-resume` |
| 分支提交 | `3f533e188008552846418bb933a1fac6367284fa` |
| 基线提交 | `64a89102824be648d937412f65d081dcd13b82a8`（`v1.6.6`） |
| 目标分支 | `feature/structured-backends` |
| 变更规模 | 12 个文件，+224 / -13 |
| 发布状态 | **未发布、未合并、未创建 PR** |

分支地址：

```text
https://github.com/Arginine-Arg/Feishu_bridge_arg/tree/review/codex-provider-resume
```

远程分支已创建并通过 `git ls-remote` 核验，指向提交 `3f533e188008552846418bb933a1fac6367284fa`。

比较地址：

```text
https://github.com/Arginine-Arg/Feishu_bridge_arg/compare/feature/structured-backends...review/codex-provider-resume
```

## 2. 问题说明

### 现象

使用 `cc-switch` 切换 Codex provider 后，旧会话无法通过 Codex、`arg-bridge native` 或 structured 模式 resume，典型错误为：

```text
failed to load configuration: Model provider `deepseek` not found
```

### 复现路径

1. 在 `cc-switch` 中使用旧 provider id（例如 `deepseek`）创建 Codex 会话。
2. 切换到新 provider（当前 `cc-switch` 使用稳定第三方 id `custom`）。
3. 对第 1 步的旧 thread 执行 resume。
4. 即使当前 `config.toml`、API key 和网络都正确，resume 仍可能在加载 thread 时失败。

### 根因

Codex 会把创建 thread 时的 `model_provider` 固化在 rollout/thread 元数据中。App Server 在 `thread/resume` 时会先解析这个历史 provider id，然后才应用当前 `config.toml`。`cc-switch` 修改的是当前配置，不会重写旧 thread 的 provider 元数据，因此：

- 当前 provider 已经变成 `custom`；
- 旧 thread 仍然指向 `deepseek`；
- App Server 找不到历史 id `deepseek`，在会话真正加载前就失败。

这不是 API key、环境变量或代理问题。仅修改 shell wrapper、导出 `OPENAI_API_KEY`、重启 app-server 或删除临时目录，都不能修复已经持久化的 thread provider 绑定。

## 3. 改造思路

Codex 的 `thread/resume` 已经支持 `modelProvider` 和 `model` 参数。修复采用“**Resume 时重新绑定当前 provider/model，但保留原会话历史**”的方式：

1. 在 App Server `initialize` 响应中捕获实际使用的 `codexHome`。
2. 从该目录的 `config.toml` 读取当前 `model_provider` 和 `model`。
3. 解析时遵循当前选中的 profile；profile 优先于顶层配置。
4. 每次 `thread/resume` 都把这些值作为默认参数。
5. 调用方显式传入的 `modelProvider` / `model` 保持最高优先级。
6. 权限覆盖参数被拒绝后的重试路径也保留同样的 provider/model 默认值。
7. 配置缺失或不可读时回退到内置 provider `openai`，不阻塞 resume。

该方案不重写历史消息、不迁移数据库、不修改 rollout 内容。Codex 会在正常 resume 流程中追加新的 thread settings，后续回合使用当前 provider/model。

## 4. 文件级改动

### 核心实现

| 文件 | 改动 |
| --- | --- |
| `src/agent/structured/rpc.ts` | 保存 `initialize` 响应中的 `codexHome`，供后续 resume 读取正确配置。 |
| `src/agent/codex/credentials.ts` | `CodexConfigSummary` 增加 `model`，解析选中 profile 或顶层的 `model`。 |
| `src/agent/codex/provider.ts` | 新增 `resolveCodexResumeDefaults()`：读取当前 `config.toml`，返回当前 provider/model；配置不可用时回退 `openai`。 |
| `src/agent/structured/permissions.ts` | `resumeCodexThread()` 合并当前 provider/model 默认值；显式参数优先；权限重试路径保持一致。 |

### 文档

| 文件 | 改动 |
| --- | --- |
| `README.md` | 说明旧 thread provider id 导致 resume 失败的原因和修复行为。 |
| `README.zh.md` | 中文说明同上。 |
| `docs/structured-backend.md` | 补充 structured resume 的 provider/model 重绑定规则。 |

### 构建产物

| 文件 | 改动 |
| --- | --- |
| `dist/cli.js` | 重新构建，和源码改动对应。 |

### 测试

| 文件 | 覆盖点 |
| --- | --- |
| `tests/unit/agent/codex-credentials.test.ts` | 向上兼容 `model` 解析；profile 覆盖顶层；原有 provider/token 行为不变。 |
| `tests/unit/agent/codex-provider.test.ts` | 当前 provider/model 解析、配置缺失回退、profile 优先级。 |
| `tests/unit/agent/structured-permissions.test.ts` | 历史 thread 使用当前 provider、显式覆盖优先、权限重试仍带默认值。 |
| `tests/unit/agent/structured-protocol.test.ts` | App Server `initialize` 返回的 `codexHome` 被正确捕获。 |

## 5. 兼容性

- 分支基于 `feature/structured-backends` 的 `v1.6.6` 提交，不引入新依赖，不改 package version。
- 已核对 Codex `0.154.0` 的 App Server schema：`ThreadResumeParams` 已支持 `model` 和 `modelProvider`，因此不提高最低 Codex 版本。
- 只影响 resume 参数构造；Codex turn-mode、credential resolution、代理选择和 thread 历史内容均未改变。
- 没有 provider 或 credential 数据写入日志。

## 6. 验证结果

在分支提交上执行：

| 检查 | 结果 |
| --- | --- |
| `git diff --check` | 通过 |
| `tsc --noEmit` | 通过 |
| 针对性测试 6 个文件 | 46/46 通过 |
| `tsup` 构建 | 通过 |
| 构建后工作区 | 无未提交差异 |

运行的测试文件：

```text
tests/unit/agent/codex-credentials.test.ts
tests/unit/agent/codex-provider.test.ts
tests/unit/agent/structured-permissions.test.ts
tests/unit/agent/structured-protocol.test.ts
tests/unit/docs/readme-contract.test.ts
tests/process/cc-switch-acceptance.test.ts
```

说明：第一次在受限沙箱中运行时，`structured-protocol` 的两个本地 WebSocket 用例因 `listen EPERM` 超时，`cc-switch-acceptance` 因子进程探测受限失败。相同命令在非沙箱执行环境重跑后 46/46 全部通过。

**未执行完整全量测试套件**；合入前应由主开发者按项目标准 CI 完整跑一遍。

## 7. 已知限制和审查重点

1. `resolveCodexResumeDefaults()` 每次 resume 同步读取一次 `config.toml`，开销很小，但请确认频率和错误策略符合项目预期。
2. 配置不可读时静默回退 `openai`。这与“不阻塞 resume”的目标一致，但请确认是否需要额外诊断日志。
3. 如果某个 App Server 版本不返回 `codexHome`，代码会回退到默认 Codex home；多 Codex home 场景请重点验证。
4. 显式传入 `modelProvider` / `model` 的调用方不会被覆盖；请确认所有调用点都符合这个优先级。
5. `dist/cli.js` 已随源码重建；请按仓库发布策略确认构建产物是否应进入提交。
6. 本分支没有修改 standalone 的 `ccs-provider-compat` 工具。该工具只是未合入上游前的临时兼容方案，不属于本 PR 的必要内容。

## 8. 主开发者审查步骤

```bash
git fetch origin review/codex-provider-resume
git diff origin/feature/structured-backends...origin/review/codex-provider-resume
git log --oneline origin/feature/structured-backends..origin/review/codex-provider-resume
```

建议重点检查：

- `src/agent/structured/rpc.ts` 的 `codexHome` 捕获。
- `src/agent/codex/credentials.ts` 对 profile 和顶层 `model` 的解析。
- `src/agent/codex/provider.ts` 的默认值和回退策略。
- `src/agent/structured/permissions.ts` 的参数合并顺序和权限重试路径。
- `tests/unit/agent/structured-permissions.test.ts` 是否覆盖了所有 resume 调用形态。

合入前至少运行：

```bash
pnpm typecheck
pnpm test:unit
pnpm test:process
pnpm build
git diff --check
```

如果项目有平台 CI、包安装验证或 cc-switch 实机验收，应一并执行。

## 9. 发布决策清单

主开发者需要明确回答：

- [ ] 方案是否正确解决“切换 provider 后旧 thread 无法 resume”。
- [ ] 当前实现是否应合入 `feature/structured-backends`，还是先移植到最新版本。
- [ ] 是否需要调整配置读取失败时的回退或诊断行为。
- [ ] 是否需要补充多 `CODEX_HOME`、远程 resume 或真实 cc-switch 场景测试。
- [ ] 是否接受 `dist/cli.js` 随分支提交。
- [ ] 如果接受，使用哪个版本号、release note 和发布时间。
- [ ] 如果不接受，给出具体修改项，而不是直接发布。

建议默认状态：**先审查和验证，不自动发布**。是否发布由主开发者决定。

## 10. 给主开发 session 的说明（可直接粘贴）

```text
你负责审查并决定是否发布一个 Codex provider 切换后的 resume 修复。

仓库：Arginine-Arg/Feishu_bridge_arg
审查分支：review/codex-provider-resume
提交：3f533e188008552846418bb933a1fac6367284fa
基线：64a89102824be648d937412f65d081dcd13b82a8（v1.6.6）
目标分支：feature/structured-backends

问题：Codex 会把 provider id 固化到旧 thread。cc-switch 切换活跃 provider 后，
App Server 先解析旧 provider id，再应用当前 config.toml，导致旧会话 resume 报
`Model provider <old-id> not found`。仅改环境变量、API key 或重启进程不能修复。

方案：在 App Server initialize 时捕获 codexHome；resume 前读取当前 config.toml
中的 model/model_provider（profile 优先）；把这些值作为 thread/resume 默认参数。
调用方显式覆盖仍然优先，权限重试路径保留默认值，不重写历史消息。

请你：
1. fetch 并审阅该分支，重点检查 rpc.codexHome 捕获、配置解析、参数优先级和权限重试。
2. 运行项目完整 CI（至少 typecheck、unit、process、build、diff check）；如可用，再跑平台 CI 和真实 cc-switch 验收。
3. 判断是否需要移植到最新版本、是否调整回退/诊断策略、是否接受已提交的 dist/cli.js。
4. 明确给出：通过 / 需修改 / 拒绝，并列出必须修改项。
5. 只有在你明确通过后才决定版本号、release note 和发布；当前分支没有创建 PR，也没有发布 Release。

请优先检查已经记录的风险：配置不可读时回退 openai、App Server 不返回 codexHome
时的默认 home 行为、多 CODEX_HOME 场景、以及完整测试覆盖是否足够。
```

## 11. 产物

本目录将打包为单个文件：

```text
arg-bridge-codex-provider-resume-review.tar.gz
```

包内包含：

- `README.md`：本交接说明。
- `codex-provider-resume.patch`：基于 `v1.6.6` 的可审阅补丁。
- `codex-provider-resume.diff`：完整 diff。
- `commit.txt`：分支、提交、基线和远端地址。
- `SHA256SUMS`：文件校验值。

校验方式：

```bash
sha256sum -c SHA256SUMS
```
